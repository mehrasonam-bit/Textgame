import networkx as nx
import matplotlib.pyplot as plt
import json
from termcolor import colored

def gamemap():
  G=nx.Graph()
  with open('deadlines.json') as f:
    data=json.load(f)
  
  for value in range (28): #number of rooms
    G.add_node(data[value]['id'])
  for value in range(28):
    G.add_edge(data[value]['id'],data[value]['c1']) #navigations through out the game to create the nodes
    G.add_edge(data[value]['id'],data[value]['c2'])
    G.add_edge(data[value]['id'],data[value]['c3'])
  ax = plt.gca()
  
  nx.draw(G,node_size=100,with_labels=True,node_color='lightgreen',ax=ax)
  _ = ax.axis('off')
  plt.title("Dungeons and Deadlines Game Map", fontdict=None, loc='center',pad=None) #title

  plt.savefig("game_map.png") #saves the graph

  print(f'{colored("Checkout Dungeons and Deadlines Game Map","yellow")}')

#https://stackoverflow.com/questions/63038379/add-title-to-networkx-plot