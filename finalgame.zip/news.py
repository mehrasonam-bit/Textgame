import json
import random
import urllib.request

from termcolor import colored
def news():
  url = f'https://newsapi.org/v2/top-headlines?country=ca&apiKey=b145bb6ad63f4b1e8a1b43bc6d95e88a'

  response = urllib.request.urlopen(url)
  result = json.loads(response.read())

 

  news=[]
  for i in range(6):
    news.append(result['articles'][i-1]['title'])

  print("Your smart watch on the wrist vibrated and kitty your virtual assitant reads out the news for you")

  print(f"{colored(random.choice(news),'yellow')}")