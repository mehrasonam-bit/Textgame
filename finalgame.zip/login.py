#import packages
import os 
import json
from twilio.rest import Client
import clearscreen as c
import pyinputplus as pyip

path = 'users' #checks if there is a user folder, if not, create it
if not os.path.exists(path):
    os.makedirs(path)
#login function
def login():
    status = input("\nDo you have an account? y/n ")
    if status.lower() == 'n':
      signup() 
    print("Welcome to Dungeons and Deadlines login page")
    user= input("Username: ")
    user = user.lower()
    password = pyip.inputPassword("Password: ")
    
    #try and catch 
    try:
      with open(os.path.join(path, user + ".json"), "r") as json_file:
        data = json.load(json_file)
      if data["username"] == user and data["password"] == password:
        print("\nLogged in, entering game!")
            
        with open("current_account.json", "w") as outfile:
          json.dump(data, outfile)
      else:
        print("Incorrect username or password, please try again")
    except FileNotFoundError:
      print("We cant find your account")
      login()

#lets users sign up to the system
def signup():
  print("\n\nPlease fill out the form to sign up ")
  user = input("Username: ")
  user = user.lower()

    #test if user account is in the system
  if os.path.isfile(os.path.join(path, user + ".json")) == True:
    print("User account is already in system")
    signup()
  
  else:
    password = pyip.inputPassword("Password: ")
    password2 = pyip.inputPassword("Password again: ")
    if password != password2:
      print("Problem with password, they do not match")
      signup()
    phone_number=input("\n Enter your phone number (with area code) :") 
    
    my_secret = os.environ['TWILIO_ACCOUNT_SID']
    auth_token = os.environ['TWILIO_AUTH_TOKEN']
    client = Client(my_secret, auth_token)

    message = client.messages \
                .create(
                     body=f"Welcome to Dungeons and Deadlines Game. Have Fun!!! Your Username: {user} and Password:{password} save it for future reference",
                     from_='+16062688927',
                     to=f'+{phone_number}'
                 )

    print("Notification has been sent to your phone\n")
    data = {}
    data["username"] = user
    data["password"] = password
    
    data["money"] = 1000
    data["location"] = 0
    data["health"] = 100
    data["stress"] = 0

    with open(os.path.join(path, user + ".json"), "w") as outfile:
      json.dump(data, outfile)

login()
c.clear()