import urllib.request
import json



TEAL    = "\033[36m"
BOLD   = "\033[1m"
ITALIC = "\033[3m"
RESET  = "\033[0m"
YELLOW = "\033[33m"
def stranger1():
  with open("current_account.json", "r") as json_file:
    json_data = json.load(json_file)
  user=json_data['username']


  url = 'http://names.drycodes.com/10?nameOptions=boy_names'

  response = urllib.request.urlopen(url)
  result = json.loads(response.read())
    
  name = result[0].split("_")
  name = name[0]

  print("A stranger is passing by, stops and start talking to you ")
  print(f"{TEAL+ITALIC}Stranger:{RESET} Hi, My name is {name}.\n")
  print("What's your name?")
  print(f"{YELLOW+ ITALIC+user}:{RESET} Hi, My name is {user}")
  print(f"{TEAL+ITALIC}Stranger:{RESET} I have an advice for you.\n")

  url='https://api.adviceslip.com/advice'
  response = urllib.request.urlopen(url)
  result = json.loads(response.read())
  print(f"{TEAL+ITALIC}Stranger:{RESET} My piece of advice is :-\n")
  print(f"{TEAL+ITALIC} {result['slip']['advice']}")