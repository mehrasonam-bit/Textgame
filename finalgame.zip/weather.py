import urllib.request
import json
import random
from termcolor import colored


def weather():
  
  with open("current_account.json", "r") as json_file:
    json_data = json.load(json_file)
    user=json_data['username']
  location = ['sudbury','dhanbad','toronto']
  my_location=random.choice(location)

  print("Your watch on wrist vibrates, Kitty your Virtual Assitant has a message for you\n")
  print(f"Hey,{colored(user,'yellow')}")

  url = f'http://api.openweathermap.org/data/2.5/weather?q={my_location}&appid=af7824ae8c177c05cefaccff7bc6c572'

  response = urllib.request.urlopen(url)
  result = json.loads(response.read())

  #current temperature
  temp_c = round(result["main"]["temp"]-273.15,2)

  #checks what to wear
  if temp_c > 20:
    print(f"Right now temperature is {temp_c} You should have worn T-shirt, its hot!\nNow see you are sweating")
  elif temp_c >10:
    print(f"Right now temperature is {temp_c} You should have worn a jacket, it's chilling outside")
  elif temp_c < -10:
    print(f"Right now temperature is {temp_c} Its very cold! You Should have worn\neverything that's there in the wardrobe")        