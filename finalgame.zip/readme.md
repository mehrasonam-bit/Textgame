Dungeons and Deadlines
This  text based adventure game was developed for final-project of BAPG
Work-Life balance?? This is for whioch we all thrive for. Lets go for a roller coaster
ride with the player how he struggles at the first day of the work. What hurdles he 
encounter while he is enroute work. Will he able to make it or he will fired??? Find
out by playing this crazy game, where player is trying to balance his work life.

Enjoy the Adventure. Choices matters. Make wise choices.

Version: 1.0

References: 
https://stackoverflow.com/questions/63038379/add-title-to-networkx-plot
https://www.geeksforgeeks.org/clear-screen-python/

Api's: 

http://names.drycodes.com/1?nameOptions=funnyWords
http://names.drycodes.com/10?nameOptions=boy_names
http://api.openweathermap.org
https://newsapi.org/v2/top-headlines?country=ca&apiKey=b145bb6ad63f4b1e8a1b43bc6d95e88a
https://zenquotes.io/api/random





