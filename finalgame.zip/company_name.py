import urllib.request
import json
from termcolor import colored

def company_name():
  #reads api
  url = 'http://names.drycodes.com/1?nameOptions=funnyWords'

  response = urllib.request.urlopen(url)
  result = json.loads(response.read())
  #retrieve's the name and remove _
  name = result[0].split("_")
  name = name[0]
  #prints info
  print(f"\n\n\n\n\nWelcome to {colored(name,'red')} Pvt Ltd. ")
  print("......try surving the probabition period without hurdle")
