#import packages
from tqdm import tqdm
import urllib.request
import time
import json
import clearscreen as c

#color codes
TEAL    = "\033[36m"
BOLD   = "\033[1m"
ITALIC = "\033[3m"
RESET  = "\033[0m"

print("Uploading Your Game,Be ready for the Fun!!!!\n")
#reads api
url ="https://zenquotes.io/api/random" 
response = urllib.request.urlopen(url)
result = json.loads(response.read()) 
#prints
print(TEAL + ITALIC + result[0]['q'] + RESET) 
print("\n")
print(f" \t\t\t\t\t\t\t\t- {BOLD}{result[0]['a']}{RESET}")
print("\n")
#progress bar
for i in tqdm (range (100), desc="Loading…", ascii=False, ncols=75):time.sleep(0.07)
#clear screen
c.clear()   
