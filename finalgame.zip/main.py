#import packages
import homepage
import login 
import os 
import json
import random
import urllib.request 
import clearscreen as c
from termcolor import colored
import weather as w
import company_name as n
import time
import game_map as g

import news as ne
import stranger1 as s1

#globals.initialize()#global variable for money updation
n.company_name()
time.sleep(5)
#json open file
with open("current_account.json", "r") as json_file:
  json_data = json.load(json_file)

path = 'users'
user=json_data['username']
#reads API
url = 'https://raw.githubusercontent.com/mehrasonam-bit/Textgame/main/deadlines.json'
response = urllib.request.urlopen(url)
data = json.loads(response.read())


#main loop where game is played
room=json_data['location']
while True:
    c.clear() #clears screen
    print ("Your current stats for the game is:\n")
    health=json_data['health']
    stress=json_data['stress']
    money=json_data['money']
    #prints stats
    print(f"{colored('Health','yellow')}: {health}\t \t {colored('Stress','yellow')}: {stress}\t \t {colored('Money','yellow')}: {money}\t \t {colored('Room','yellow')}: {room+1}\n ")
    
    chance = random.randint(1,2)
    #calls various api's
    if chance==1 and  data[room]["kitty"] == 1:
      health-=10
      w.weather()
    
    if chance==2 and  data[room]["kitty"] == 1:
      ne.news()
      stress+=20
      
    if chance == 1 and data[room]["stranger"] == 1:
      s1.stranger1()
      stress+=10
    if chance==2 and data[room]["stranger"]== 1:
      cost = random.randint(1,500)
      print("The stranger wants to help you and give you a ride to your work.\nBut he wants to negotiate about the fare")
      while True:

        choice = int(input("\nHow much you want to pay for the ride? "))
      
        if choice > (100 + cost):
          print("That's crazy! I would never go at that price! Try to make a more resonable offer")
        elif choice > (25+cost):
          print("That's unexceptable. Considering the situation at least be bit considerate")
        elif (choice > (0+cost)) or (choice > (-10 + cost)):
          print("Thankfully, we both agree on one this. Let's go I will drop you at work")
          break  
        else: 
          print("Hey!! man atleast give proper value to the service being offered.\nLet's do it again")        
        money-=choice

      
    #prints story of the room
    print(data[room]["story"])

    #resets the value to original value 
    if data[room]["win"] == 1:
      json_data['money']=1000
      json_data['health']=100
      json_data['stress']=0
      json_data['location']=0
      #dumps the current value to current account of the player
      with open("current_account.json", "w") as outfile:
        json.dump(json_data, outfile)
      #dumps current value to user's json file
    
      with open(os.path.join(path, user + ".json"), "w") as outfile:
        json.dump(json_data, outfile)
        break
    #resets the value 
    if data[room]["loose"] == 1:
      json_data['money']=1000
      json_data['health']=100
      json_data['stress']=0
      json_data['location']=0
      #dumps the current value to current account of the player
      with open("current_account.json", "w") as outfile:
        json.dump(json_data, outfile)
      #dumps current value to user's json file
    
      with open(os.path.join(path, user + ".json"), "w") as outfile:
        json.dump(json_data, outfile)  
        break

    print(f"\n{colored(data[room]['nav'],'red')}\n")
    #navigation
    choice = input("Please make a selection ")
    if choice == '1':
        room = data[room]["c1"] - 1
    elif choice == '2':
        room = data[room]["c2"] - 1
    elif choice == '3':
        room = data[room]["c3"] - 1
    
    else:
        print("Please select a valid option")   
    #updating current json with current values
    json_data['health']= health
    json_data['location']=room+1
    json_data['money']=money
    json_data['stress']=stress

    #dumps the current value to current account of the player
    with open("current_account.json", "w") as outfile:
      json.dump(json_data, outfile)
    #dumps current value to user's json file
    
    with open(os.path.join(path, user + ".json"), "w") as outfile:
      json.dump(json_data, outfile)
    
    
g.gamemap()


    